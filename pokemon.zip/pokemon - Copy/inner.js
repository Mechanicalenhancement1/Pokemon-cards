document.addEventListener("DOMContentLoaded", async function () {
    // define the URL for fetching the list of the first 151 pokemon
    const pokemonListUrl = "https://pokeapi.co/api/v2/pokemon?limit=151";

    // reference to the container where pokemon cards will be displayed
    const pokemonContainer = document.querySelector(".pokemon-cards");

    // reference to filter and sort elements
    const filterInput = document.getElementById("filter");
    const filterButton = document.getElementById("filterButton");
    const sortSelect = document.getElementById("sort");
    const sortButton = document.getElementById("sortButton");

    // function to fetch and display details for an individual pokemon (async/await)
    async function fetchPokemonData(url) {
        try {
            const response = await fetch(url);
            const data = await response.json();
            // create a pokemon card HTML element
            const pokemonCard = createPokemonCard(data);

            // append the card to the container
            pokemonContainer.appendChild(pokemonCard);
        } catch (error) {
            console.error("Error fetching Pokemon data:", error);
        }
    }

    // function to create a pokemon card HTML element
    function createPokemonCard(pokemon) {
        const card = document.createElement("div");
        card.classList.add("pokemon-card");

        // add pokemon number, name, and type(s)
        card.innerHTML = `
            <img src="${pokemon.sprites.other.dream_world.front_default}" alt="${pokemon.name}">
            <h3>${pokemon.name}</h3>
            <p>Number: ${pokemon.id}</p>
            <p>Type(s): ${pokemon.types.map((type) => type.type.name).join(", ")}</p>
        `;

        return card;
    }

    // function to generate and append pokemon cards
    async function generatePokemonCards() {
        pokemonContainer.innerHTML = ""; // Clear existing cards

        try {
            const response = await fetch(pokemonListUrl);
            const data = await response.json();
            const pokemonList = data.results;

            // fetch and display details for each pokemon
            for (const pokemon of pokemonList) {
                await fetchPokemonData(pokemon.url);
            }
        } catch (error) {
            console.error("Error fetching Pokemon list:", error);
        }
    }

    // event listener for filtering pokemon
    filterButton.addEventListener("click", function () {
        const filterText = filterInput.value.toLowerCase();
        const pokemonCards = document.querySelectorAll(".pokemon-card");

        pokemonCards.forEach((card) => {
            const name = card.querySelector("h3").textContent.toLowerCase();
            const id = card.querySelector("p").textContent.toLowerCase();

            if (name.includes(filterText) || id.includes(filterText)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });

    // event listener for searching pokemon by pressing enter
    filterInput.addEventListener("keyup", function (event) {
        if (event.key === "Enter") {
            // Clear the display of all cards before applying the filter
            const pokemonCards = document.querySelectorAll(".pokemon-card");
            pokemonCards.forEach((card) => {
                card.style.display = "none";
            });

            // triggering the filterButton click event
            filterButton.click();
        }
    });

    // function to sort pokemon cards by ID (ascending)
    function sortByIdAsc() {
        const pokemonCards = Array.from(document.querySelectorAll(".pokemon-card"));
        pokemonCards.sort((a, b) => {
            const idA = parseInt(a.querySelector("p").textContent.split(":")[1]);
            const idB = parseInt(b.querySelector("p").textContent.split(":")[1]);
            return idA - idB;
        });

        // remove existing cards and append sorted cards
        pokemonContainer.innerHTML = "";
        pokemonCards.forEach((card) => {
            pokemonContainer.appendChild(card);
        });
    }

    // function to sort pokemon cards by ID (descending)
    function sortByIdDesc() {
        const pokemonCards = Array.from(document.querySelectorAll(".pokemon-card"));
        pokemonCards.sort((a, b) => {
            const idA = parseInt(a.querySelector("p").textContent.split(":")[1]);
            const idB = parseInt(b.querySelector("p").textContent.split(":")[1]);
            return idB - idA;
        });

        // remove existing cards and append sorted cards
        pokemonContainer.innerHTML = "";
        pokemonCards.forEach((card) => {
            pokemonContainer.appendChild(card);
        });
    }

    // function to sort pokemon cards by name (Ascending)
    function sortByNameAsc() {
        const pokemonCards = Array.from(document.querySelectorAll(".pokemon-card"));
        pokemonCards.sort((a, b) => {
            const nameA = a.querySelector("h3").textContent.toLowerCase();
            const nameB = b.querySelector("h3").textContent.toLowerCase();
            return nameA.localeCompare(nameB);
        });

        // remove existing cards and append sorted cards
        pokemonContainer.innerHTML = "";
        pokemonCards.forEach((card) => {
            pokemonContainer.appendChild(card);
        });
    }

    // function to sort pokemon cards by name (Descending)
    function sortByNameDesc() {
        const pokemonCards = Array.from(document.querySelectorAll(".pokemon-card"));
        pokemonCards.sort((a, b) => {
            const nameA = a.querySelector("h3").textContent.toLowerCase();
            const nameB = b.querySelector("h3").textContent.toLowerCase();
            return nameB.localeCompare(nameA);
        });

        // remove existing cards and append sorted cards
        pokemonContainer.innerHTML = "";
        pokemonCards.forEach((card) => {
            pokemonContainer.appendChild(card);
        });
    }

    // event listener for sorting Pokemon
    sortButton.addEventListener("click", function () {
        const selectedOption = sortSelect.value;

        if (selectedOption === "id-asc") {
            sortByIdAsc();
        } else if (selectedOption === "id-desc") {
            sortByIdDesc();
        } else if (selectedOption === "name-asc") {
            sortByNameAsc();
        } else if (selectedOption === "name-desc") {
            sortByNameDesc();
        }
    });

    // generate and display Pokemon cards when the page loads
    generatePokemonCards();
});